Simple C Parser - Recursive Descent

Author: Saurav Keshari Aryal

Instructor: Dr. Jiang Li

Assignment: Syntax Analysis

Course: Structures of Programming Languages - S2017

Howard University, Washington DC.

######################################################################################

Compile and Execution Instructions

To run the parser use the following commands(as tested on Ubuntu 16.04 LTS on amd64):
$ make          
$ ./parser <filename>
where, <filename> will be replaed by a real file name

To clean the build:
$ make clean

######################################################################################

Github URL:
https://github.com/Saurav-K-Aryal/SimpleCParser

######################################################################################

Commit History:

commit 58e6de615cd6741e1d31ac21858b677972c60bf7
Author: Saurav-K-Aryal <saurav.aryal@bison.howard.edu>
Date:   Wed Mar 22 15:26:27 2017 -0400
Description: first simple parser from book; now looking at second one
URL: https://github.com/Saurav-K-Aryal/SimpleCParser/commit/58e6de615cd6741e1d31ac21858b677972c60bf7


commit 09ea424f42006076ab9d6995a0edbcb3c5f5f77e
Author: Saurav-K-Aryal <saurav.aryal@bison.howard.edu>
Date:   Wed Mar 22 22:14:50 2017 -0400
Description: updated parser; added expression parser from book
URL: https://github.com/Saurav-K-Aryal/SimpleCParser/commit/09ea424f42006076ab9d6995a0edbcb3c5f5f77e

commit 2172c3378919f4b4728460721437fd6048d03c05
Author: Saurav-K-Aryal <saurav.aryal@bison.howard.edu>
Date:   Wed Mar 22 23:52:35 2017 -0400
Description: Added and adapted expr, term, factor, and error function.
URL: https://github.com/Saurav-K-Aryal/SimpleCParser/commit/2172c3378919f4b4728460721437fd6048d03c05

commit daa8beeb56e3caf4a2193164478f312c3386a593
Author: Saurav-K-Aryal <saurav.aryal@bison.howard.edu>
Date:   Thu Mar 23 01:43:44 2017 -0400
Description: Added support for parsing multiple lines
URL: https://github.com/Saurav-K-Aryal/SimpleCParser/commit/daa8beeb56e3caf4a2193164478f312c3386a593

commit b58fa41ced3c7fa12288610d1a41d9a877189b73
Author: Saurav-K-Aryal <saurav.aryal@bison.howard.edu>
Date:   Thu Mar 23 02:39:41 2017 -0400
Description: Simple command line argument handling implemented and added makefile.
URL: https://github.com/Saurav-K-Aryal/SimpleCParser/commit/b58fa41ced3c7fa12288610d1a41d9a877189b73

######################################################################################

For the entire git diff log feel free to visit:
https://github.com/Saurav-K-Aryal/SimpleCParser/blob/master/git_log
